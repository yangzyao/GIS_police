//兴趣点路由
require("./interestPoint");