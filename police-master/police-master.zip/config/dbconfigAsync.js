var DB_CONFIG_ASYNC = {
	host:'211.103.178.205',
	user:'KingDragon',
	password:'939407Lq252324',
	database:'xc_baymin',
	port:3306
}

module.exports = DB_CONFIG_ASYNC;
// module.exports = DB_TExST_CONFIG;