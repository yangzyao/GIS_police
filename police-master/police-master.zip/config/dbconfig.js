var DB_CONFIG = {
	host:'127.0.0.1',
	user:'KingDragon',
	password:'939407Lq252324',
	database:'police',
	port:3306
}

var DB_TEST_CONFIG = {
	host:'xiaofen809.com',
	user:'root',
	password:'939407Lq252324',
	database:'police',
	port:3306
}

module.exports = DB_CONFIG;
// module.exports = DB_TEST_CONFIG;