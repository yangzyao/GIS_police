var cameraAttrList = [
						'cam_id', 
						'cam_no', 
						'cam_name', 
						'cam_sta', 
						'addtime', 
						'uptime', 
						'user_id', 
						'cam_loc_lan', 
						'cam_loc_lon', 
						'cam_desc', 
						'cam_addr'
					];

exports.cameraAttrList = cameraAttrList;