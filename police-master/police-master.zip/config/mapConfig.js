var mapConfig = {
	host: '10.161.236.119',
	port: 8080
}

module.exports = mapConfig;
