var carAttrList = [
						'id', 
						'car_x', 
						'car_y', 
						'car_no', 
						'car_addr', 
						'car_type'
					];

exports.carAttrList = carAttrList;